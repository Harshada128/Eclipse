package com.java11Streams;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class AsendDese {

	public static void main(String[] args) {
		
		List<Emp> emp = Arrays.asList (
				new Emp ("Aohn", "Smith"),
				new Emp ("Peter", "Sam"),
				new Emp ("Thomas", "Wale"));
		
				List<Emp> result = emp.stream()
				//.sorted (Comparator.comparing(Emp::getfName).thenComparing(Emp::getlName))
				//.map(Emp::getfName).sorted(Comparator.reverseOrder())
				.sorted (Comparator.comparing(Emp::getfName).reversed().thenComparing(Emp::getlName))
				.collect(Collectors.toList());
				
				for(Emp emp2 : result) {
					
					System.out.println(emp2.getfName() +" & " + emp2.getlName());
				}        

	}

}
