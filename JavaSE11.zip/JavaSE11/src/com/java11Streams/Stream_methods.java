package com.java11Streams;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class Stream_methods {

	public static void main(String[] args) {
		

		List<Employee> employee = new ArrayList<>();
		
        Collections.addAll(employee, new Employee(1, "Amit", 10000),
        		new Employee(2, "Ramesh", 200000), 
        		new Employee(3, "Vishal", 300000),
        		new Employee(4, "Shital", 300));
        
        List<Employee> filEmp = employee.stream()
        		.filter(emp -> emp.getEmpl_salary() >= 1000)
        		.collect(Collectors.toList());
        
        for (Employee employee2 : filEmp) {
            System.out.println(employee2.getEmpl_name());
        }
		
	}

}
