package com.java11Streams;

public class StringClassMethod {

	public static void main(String[] args) {
		
//		String name = "  jhbi  hjhgjgh  ";
//		
//		System.out.println(name.trim());
//	

	String name1 = "  ";
	
	if(name1.isBlank()) {
		System.out.println(" Name is required");
	}
	
	
//	String name2 = "  ";
//	
//	if(name2.isEmpty()) {
//		System.out.println(" Name is required");
//	}else {
//		System.out.println(" false");
//	}
		
		
//		String name3 = "  ";
//		
//		if(name3.compareTo("Name")== 0) {
//			System.out.println(" Name is required");
//		}
//		
//	
	}
}
