package com.java11Streams;

public class Emp {

	String fName;
	String lName;
	
	public Emp (String fn, String ln) {
	fName = fn;
	lName = ln;
	}
	
	public String getfName() 
	{ 
		return fName; 
	}
	public String getlName() 
	{ 
		return lName; 
	}
}
