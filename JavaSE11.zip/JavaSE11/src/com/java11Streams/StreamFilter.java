package com.java11Streams;

import java.util.Arrays;
import java.util.List;

public class StreamFilter {

	public static void main(String[] args) {
		
		List<Employee> emplyees = Arrays.asList(
				new Employee(101, "Manish", 35000),
				new Employee(12, "Manisha", 15000),
				new Employee(10, "Nisha", 55000),
				new Employee(86, "Umesh", 5000),
				new Employee(11, "Ramesh", 335000)
				);
		
		long count = emplyees.stream()
					.filter(e -> e.getEmpl_salary() >=10000)
					.count();
									
		System.out.println("Employees whose salary > 10k : " + count);
	}

}
