package com.java11Streams;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Stream_Map {

	public static void main(String[] args) {
		
		List<String> elements = Arrays.asList("apple", "banana", "orange", "apple", "banana", "apple");
        // Using Java streams to count the frequency of elements
        Map<String, Long> frequencyMap = elements.stream()
                .collect(Collectors.groupingBy(e -> e, Collectors.counting()));
        // Displaying the frequency map
        frequencyMap.forEach((element, count) -> System.out.println(element + ": " + count));
	}

}
