package com.java11Streams;

public class Employee {
	
	private int Empl_no;
	private String Empl_name;
	private double Empl_salary;

	
    Employee(int Empl_no, String Empl_name, int Empl_salary) {
    	this.Empl_no = Empl_no;
    	this.Empl_name = Empl_name;
    	this.Empl_salary = Empl_salary;
	}
	
	public int getEmpl_no() {
		return Empl_no;
	}
	
	public String getEmpl_name() {
		return Empl_name;
	}
	
	public double getEmpl_salary() {
		return Empl_salary;
	}
	

}
