package com.java11Streams;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.stream.Collectors;

public class Stream_Distinct {

	public static void main(String[] args) {
		List<Integer> myList = Arrays.asList(9,8,9,2,7,2);
		
//		myList.stream()
//			.collect(Collectors.toCollection(SortedSet::new))
//			.stream().forEach(x -> System.out.print(x));
		
//		myList.stream()
//			.distinct()
//			.forEach(x -> System.out.print(x)); //= output :-9827
	
//		myList.stream()
//			.collect(Collectors.toCollection(HashSet::new))
//			.sorted().forEach(x -> System.out.print(x));
			
		myList.stream()
		.collect(Collectors.toCollection(TreeSet::new))
		.stream().forEach(x -> System.out.print(x));
	}

}
