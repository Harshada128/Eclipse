package com.java11Part2.test;

import java.util.List;
import java.util.Optional;

public class Program6 {

	public static void main(String[] args) {
		var fruits = List.of("apple", "orange", "banana", "lemon");
		Optional<String> result = fruits.stream().filter(f -> f.contains("n")).findAny();
		System.out.println(result.get());
	}

}
