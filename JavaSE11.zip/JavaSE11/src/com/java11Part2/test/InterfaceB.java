package com.java11Part2.test;

import java.util.Collection;

public interface InterfaceB extends InterfaceA {
	
	public Collection a();
	
}
