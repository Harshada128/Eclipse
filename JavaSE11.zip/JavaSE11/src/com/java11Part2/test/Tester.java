package com.java11Part2.test;

public class Tester {

	public static void main(String[] args) {
		
		A obj = new B();
		System.out.print(obj.x);
	}

}
