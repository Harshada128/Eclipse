package com.java11Part2.test;

public class Test2 {
	
	private final int x = 1;
	static final int y = 0;
	
	public Test2() {
		System.out.println(x);
		System.out.println(y);
		
	}

	public static void main(String[] args) {
		new Test2();

	}

}
