package com.java11Part2.test;

import java.util.Collection;

public class Foo {
	
	public void foo(Collection arg) {
		System.out.println(" Bonjour le model!");
	}

}
