package com.java11Part2.test;

import java.util.ArrayList;
import java.util.List;

public class Program {

	public static void main(String[] args) {
		
		class main <T extends Worker> extends Thread{
			private List<T> processes = new ArrayList<>();
			public void addProcess(T w) {
				processes.add(w);
			}
			
			public void run() {
				processes.forEach((p)->p.doProcess());
				
			}
		}

	}

}
