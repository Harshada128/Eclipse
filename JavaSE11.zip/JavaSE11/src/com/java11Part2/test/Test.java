package com.java11Part2.test;

public class Test {

	public static void main(String[] args) {
		
		AnotherClass ac = new AnotherClass();
		SomeClass sc = new SomeClass();
		//ac = sc ;
		//sc = ac;
		ac.methodA();
		sc.methodA();
	}



}


