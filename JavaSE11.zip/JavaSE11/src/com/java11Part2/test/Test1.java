package com.java11Part2.test;

public class Test1 {

	public void process(byte v) {
		System.out.println("Byte value " + v);
		
	}
	
	public void process(short v) {
		System.out.println("Short value " + v);
		
	}
	
	public void process(Object v) {
		System.out.println("Object value " + v);
		
	}
	public static void main(String[] args) {
		byte x = 12;
		short y = 13;
		new Test1().process(x+y);
	}

}
