//package com.java11Part2.test;
//
//public interface InterfaceD extends InterfaceB, InterfaceC {	
//	
//}
