package com.java11Part2.test;

public class Cherater implements Worker {
	
	public void doProcess() {
		
	}
}
