package com.java11Part2.test;

public interface AbilityB {
	 void action();
}
