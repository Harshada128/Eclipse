package com.java11Part2.test;

public class Program2 {
	
	private static int i;
	private static int[] primes = {2,3,5,7};
	private static String result = "";
	
	public static void main(String[] args) {
		
		System.out.println(primes.length);
		while(i < primes.length) {
			if(i == 3) {
				System.out.println("i is 3");
				break;
			}
			i++;
			result += primes[i];
			System.out.println(result);
		}
		System.out.println(result);

	}

}
