package com.java11Part2.test;

public class HardWorker implements Worker {
	
	public void doProcess() {
		System.out.println("doing things");
	}

}
