package com.java11Part2.test;

public class A {
	public int x = 42;
	
	protected A() {
		
	}
	
}
