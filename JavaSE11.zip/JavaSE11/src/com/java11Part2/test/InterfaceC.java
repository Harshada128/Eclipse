package com.java11Part2.test;

import java.nio.file.Path;

public interface InterfaceC extends InterfaceA {
	
	public Path a();
}
