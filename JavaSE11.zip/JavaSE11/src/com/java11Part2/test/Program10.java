package com.java11Part2.test;

public class Program10 {

	public static void main(String[] args) {

		var i =10;
		var j = 5;
		i += (j*5+i)/j-2;
		System.out.println(i);
	}

}
