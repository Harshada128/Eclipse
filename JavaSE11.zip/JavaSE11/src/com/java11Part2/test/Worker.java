package com.java11Part2.test;

public interface Worker {
	
	public void doProcess();

}
