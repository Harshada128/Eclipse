package com.java11Part2.test;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Program12 {

	public static void main(String[] args) {
		//String filename = "lines.txt";
		String filename = "C:\\Users\\003OQX744\\eclipse-workspace\\JavaSE\\src\\com\\java11Part2\\test\\lines.txt";
		
		List<String> list = new ArrayList<>();
		try(Stream<String> stream = Files.lines(Paths.get(filename))){
			
			list = stream
					.filter(line -> !line.equalsIgnoreCase("JAVA"))
					.map(String::toUpperCase)
					.collect(Collectors.toList());
		}
		catch(IOException e) {
			
		}
		
		list.forEach(System.out::println);
	}

}
