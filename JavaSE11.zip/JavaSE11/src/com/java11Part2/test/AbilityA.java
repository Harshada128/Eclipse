package com.java11Part2.test;

public interface AbilityA {
	
	default void action() {
		System.out.println("a action");
	}

}
