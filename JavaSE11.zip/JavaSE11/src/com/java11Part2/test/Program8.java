package com.java11Part2.test;

import java.util.ArrayList;
import java.util.Iterator;

public class Program8 {

	
	
	public static void main(String[] args) {
		
		/*
		 * var list = List.of(1,2,3,4,5,6,7,8,9,10); UnaryOperator<Integer> u = i ->
		 * i*2;
		 * 
		 * UnaryOperator u = (int i) ->i*2; list.replaceAll(u);
		 * 
		 */
		
		ArrayList<Integer> al = new ArrayList<>();
		al.add(1);
		al.add(2);
		al.add(3);
		
		Iterator<Integer> itr = al.iterator();
		while(itr.hasNext()) {
			if(itr.next()== 2) {
				al.remove(2);
				System.out.print(itr.next());
			}
		}
	}

}
