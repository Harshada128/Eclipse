package com.java11Part2.test;

public class SomeClass {
	
	public void methodA() {
		System.out.println("SomeClass#methodA()");
	}
	

}
