package com.java11Part2.test;

public class Test3 implements AbilityA, AbilityB{
	
	public void action() {
		System.out.println("ab action");
	}

	public static void main(String[] args) {
		AbilityB x = new Test3();
		x.action();
	}

}
