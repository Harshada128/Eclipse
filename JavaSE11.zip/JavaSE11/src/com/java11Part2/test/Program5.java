//package com.java11Part2.test;
//
//import java.util.List;
//import java.util.function.Consumer;
//import java.util.function.Function;
//import java.util.function.Supplier;
//
//public class Program5 {
//
//	public static void main(String[] args) {
//		//Consumer function = (String f)->(System.out.println(f));};
//		//Function function = X -> ((String) X).substring(0,2);
//		
//		//Predicate function = a ->a.equals("banana");
//		
//		//Supplier function = () -> fruits.get(0);
//		
//		var fruits = List.of("apple", "orange", "banana", "lemon");
//		fruits.forEach(function);
//	}
//
//}
