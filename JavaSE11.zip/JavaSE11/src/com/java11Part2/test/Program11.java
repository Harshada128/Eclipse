package com.java11Part2.test;

import java.util.List;
import java.util.function.UnaryOperator;

public class Program11 {

	public static void main(String[] args) {
		var list = List.of(1,2,3,4,5,6,7,8,9,10);
		UnaryOperator<Integer> u = i -> i*2;
		 
		//UnaryOperator u = (int i) ->i*2; 
		
		//UnaryOperator u = (var i) ->(i*2); 
		
		//UnaryOperator u = i ->{return i * 2;};
		
		list.replaceAll(u);
	}

}
