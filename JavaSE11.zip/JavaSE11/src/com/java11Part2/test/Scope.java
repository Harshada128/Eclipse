package com.java11Part2.test;

public class Scope {

	static int myint = 999;
	
	public static void main(String[] args) {
		int myint = 0;
		//int myint = myint;
		System.out.println(myint);
	}

}
