package com.java11Part2.test;

public class B extends A {
	int x = 17;
	public B() {
		super();
	}
	
}
