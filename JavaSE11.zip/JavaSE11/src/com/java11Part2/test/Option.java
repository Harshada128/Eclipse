package com.java11Part2.test;

import java.util.Optional;

public class Option {

	public static void main(String[] args) {
		
		System.out.println("Ans :" +convert("a").get());
	}
	
	private static Optional<Integer> convert(String s){
		
		try {
			return Optional.of(Integer.parseInt(s));
		}
		catch(Exception e) {
			return Optional.empty();
			
		}
		
	}

}
