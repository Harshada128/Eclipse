package com.java11Part2.test;

public class Program9 {

	public static void main(String[] args) {
		
		Integer i = 11;
		
		//Double c = (Double)i;
		
		Double d = Double.valueOf(i);
		
		//Double a = i; 
		
		//double e = Double.parseDouble(i);
		
		double e = i;
		
		System.out.println(e);
		
		System.out.println(d);
	}

}
