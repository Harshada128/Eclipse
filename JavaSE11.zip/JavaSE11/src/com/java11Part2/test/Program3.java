package com.java11Part2.test;

public class Program3 {
	
	class Super{
		final int num;
		public Super(int num) {
			this.num = num;
		}
	}
	
	class Sub extends Super{
		int num;
		Sub(short num){
			super(num);
		}
		
		protected void method() {
			System.out.println("Output from Sub");
		}
	}
	public static void main(String[] args) {
		//Super s = new Super(0);
	}

}
