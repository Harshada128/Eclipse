package com.java11Part2.test;

public class AnotherClass extends SomeClass {
	
	public void methodA() {
		System.out.println("AnotherClass#methodA()");
	}
}
