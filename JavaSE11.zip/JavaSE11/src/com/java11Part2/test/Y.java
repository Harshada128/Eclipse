package com.java11Part2.test;

public class Y extends X{
	
	public Y(String name) {
		super();
		setName(name);
		
	}
	
	
	/*public void setName(String name) {
		// TODO Auto-generated method stub
		
	}*/


	public static void main(String[] args) {
		Y y = new Y("HH");
		System.out.println(y);
	}

}
