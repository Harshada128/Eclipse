package com.java11Part2.test;

public interface InterfaceA {
	
	public Iterable a();
}
