package com.java11Part1.test;

public class Program13 {

	public static void main(String[] args) {
		
		class DNASynth{
			
			int aCount;
			int tCount;
			int cCount;
			int gCount;
			
			DNASynth(int a, int tCount, int c,int g){
				//setCCount(c) = cCount;//not allowed
				cCount = setCCount(c);
				this.tCount = tCount;
				setGCount(g);
				aCount = a;
				System.out.println(cCount);
			}
			
			int setCCount(int c) {
				return c;
			}
			
			void setGCount(int gCount) {
				this.gCount = gCount;
			}
			
		}
	}

}
