package com.java11Part1.test;

public class Program16 {

	public static void main(String[] args) {
		Person1 p = new Person1();
		p.setName("Blue");
		System.out.println(p);
	}

}
