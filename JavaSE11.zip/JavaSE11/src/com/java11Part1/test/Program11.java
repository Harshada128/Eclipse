package com.java11Part1.test;

import java.util.List;

public class Program11 {

	public static void main(String[] args) {
		List<Integer> list = List.of(11,12,13,12,13);
		
		//Double d = list.get(0);//cannot convert Integer to Double
		
		double f =list.get(0);
		System.out.println("f");
		
		Integer a = Integer.valueOf(list.get(0));
		System.out.println("a");
		
		Integer b = list.get(0);
		System.out.println("b");
		
		int c = list.get(0);
		System.out.println("c");
		
		Double d = Double.valueOf(list.get(0));
		System.out.println("d");

		}

}
