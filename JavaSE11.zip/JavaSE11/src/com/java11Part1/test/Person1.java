package com.java11Part1.test;

public class Person1 {
	
	private String name ="Green";
	
	public void setName(String name) {
		String title = "Mr. ";
		name = title + name;
	}
	
	public String toString() {
		return name;
	}

}
