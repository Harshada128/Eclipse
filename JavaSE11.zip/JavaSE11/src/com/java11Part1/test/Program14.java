package com.java11Part1.test;

public class Program14 {

	public static void main(String[] args) {
		Timetamp  ts = new Timetamp(1);
	}

}
