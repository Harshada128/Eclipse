package com.java11Part1.test;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class Bar extends Program20 {
	 
		 public void foo(List arg) {
			 System.out.println("Hello World! ");
		 }
		 
		 public static void main(String[] args) {
			 List<String> li = new  ArrayList<>();
			 Collection<String> co = li;
			 Bar br = new Bar();
			 br.foo(li);
			 br.foo(co);
			 
		 }
		
	}
	


