package com.java11Part1.test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Program5 {

	public static void main(String[] args) {
		List<String> list1 = new ArrayList<>();
		list1.add("A");
		list1.add("B");
		//List<String> list2 = new ArrayList<>();
		List<String> list2 = Collections.unmodifiableList(list1);
		list1.add("C");
		//list1.add("D");
		//list1.clear();
		System.out.println(list1);
		System.out.println(list2);

	}

}
