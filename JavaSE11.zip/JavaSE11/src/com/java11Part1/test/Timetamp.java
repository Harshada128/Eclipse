package com.java11Part1.test;

public class Timetamp {

	public Timetamp(int i) {
		System.out.println("Hi....");
	}

}
