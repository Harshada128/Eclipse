package com.java11Part1.test;

public abstract class AbstractAPI {
	 
	public  abstract void  process();
	
}
