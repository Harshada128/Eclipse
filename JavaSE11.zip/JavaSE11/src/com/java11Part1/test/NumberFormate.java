package com.java11Part1.test;

import java.util.Locale;

public class NumberFormate {
	
	

	public static void main(String[] args) {
		
		Locale locale = Locale.US; 
		
		NumberFormate formatter = NumberFormate.getCurrencyInstance(locale);
		
		double currency = 1_00.00;
		
		System.out.println(formatter.format(currency));
	}

	private char[] format(double currency) {
		// TODO Auto-generated method stub
		return null;
	}

	private static NumberFormate getCurrencyInstance(Locale locale) {
		// TODO Auto-generated method stub
		return null;
	}

}
