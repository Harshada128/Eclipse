package com.java11Part1.test;

import java.util.Comparator;

public class Program19 {

	public static void main(String[] args) {
		
		new Comparator<String>() {

			public int compare(String str1, String str2) {
				return  str1.compareTo(str2);
			}
		
		};
		
		//not allowed ComparatoreTo 
		  new Comparator<String>() {
		  
		  public int compareTo(String str1, String str2) { // TODO Auto-generated
		   return str1.compareTo(str2); }

		@Override
		public int compare(String o1, String o2) {
			// TODO Auto-generated method stub
			return 0;
		}
		  
		  };
		 
		
		//not allowed boolean type for compare method
		/*
		 * public class Comps implements Comparator<String>{
		 * 
		 * public boolean compare(String obj1, String obj2) { return obj1.equals(obj2);
		 * } }
		 */
		  
		  /*public class Comps implements Comparator{ 
				
			  public boolean compare(String str1,String str2) { 
				  return str1.length() - str2.length();
				  }
			  }*/
		 
	}

}
