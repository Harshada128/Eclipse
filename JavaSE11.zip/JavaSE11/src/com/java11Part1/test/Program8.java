package com.java11Part1.test;

public class Program8 {

	public static void main(String[] args) {
		//int [][][] e = {{1,1,1},{2,2,2}};//not allowed
		short sh = (short)'A';
		System.out.println(sh);
		
		float x = 1f;
		System.out.println(x);
		
		byte b = 10;
		System.out.println(b);

		//char c = b;//not allowed
		//String contact# ="(+2)(999)(232)";//not allowed
		
		String contact2 ="(+2)(999)(232)";
		System.out.println(contact2);
		
		int Y = 12_34;
		System.out.println(Y);
		
		//boolean false = (4!=4);//not allowed
		


	}

}
