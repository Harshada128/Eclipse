package com.java11Part1.test;

public interface APIInterface {
	
	public  default void process() {
		System.out.println("Process()called 1.");
	}

} 
 