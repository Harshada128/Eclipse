package com.java11Part1.test;

public class Program7 {

	public static void main(String[] args) {
		var i = 0;
		System.out.println(i);
		
		i = 'a'; //automatically convert from char to int and vice-versa
		System.out.println(i); // ascii value of a to z is 97 to 122
		
		i = 'A'; // ascii value of A to Z is 65 to 90
		System.out.println(i);
		
		i = '';
		System.out.println(i); // ascii value of '' is 5;
		
		/*i = "a";  //cannot convert from String to int, casting of string to int is not possible. 
		//If we change type of variable i to string, it will compile.
		System.out.println(i);*/

		var j = 7;
		System.out.println(j);

		var s = "hi";
		System.out.println(s);
		
		//var p = null;//cannot initialized to null
		//System.out.println(p);
		
		/*var c;//cannot use without initializer		
		var char;//cannot use create var variable with data type name
		var int = 10;//cannot use create var variable with datatype name with initialized
		var else = 10;//Keywords cannot be used for variable name
		var if;//Keywords cannot be used for variable name
		var x = 3, y = 5;//var is not allowed compound declaration
		var m = 3; var n = 5;
		var array[] = {1,2,3,4,5};//not allowed Array type of element
		var arr = {2,4,8};//Array initializer needs an explicit type
		public var z;//Modifiers not allowed*/
		
		int var = 5;//Valid but not recommended 
					//old code like this won't break under java11
		System.out.println(var);
		
		var Var = 10;
		System.out.println(Var);
		
		final var breed = "german";
		System.out.println(breed);
		
		var a = 'a';
		System.out.println(a);
		
		a = 'z'; //automatically convert from int to char and vice-versa
		System.out.println(a);
		
		a = 41; // ascii value of ')' is 41
		System.out.println(a);
		
		/*a = "Hey"; //cannot convert from String to char, casting of string to char is not possible. 
		//If we change type of variable 'a' to string, it will compile.
		System.out.println(a);*/
		
		//a = 3.5; //cannot convert automatically from double to char
		a = (char) 5.7; // char @ ascii value will be printed
		System.out.println(a);
		
		//a = 3.5f; //cannot convert automatically from float to char
		a = (char) 3.9f;
		System.out.println(a);
		
		//var a = 'a';//Variable a is already declared
		
		var f = 4.0f;
		var g = 3.5d;
		var h = 5.2;
		System.out.println("f is " + f +", g is " + g + ", h is " + h);
	}

}
