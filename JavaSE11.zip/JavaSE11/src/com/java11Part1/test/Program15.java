package com.java11Part1.test;

import java.util.function.BiPredicate;

public class Program15 {

	public static void main(String[] args) {
		
		//BiPredicate<Integer, Integer> test = (Integer x,final var y)->(x.equals(y));
		
		BiPredicate<Integer, Integer> test1 = (Integer x,final Integer y)->(x.equals(y));
		
		//BiPredicate<Integer, Integer> test2 = (final Integer x,var y)->(x.equals(y));
		
		BiPredicate<Integer, Integer> test3 = (var x,final var y)->(x.equals(y));
		
		//BiPredicate<Integer, Integer> test = (final var x,y)->(x.equals(y));




	}

}
