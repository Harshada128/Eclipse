package com.java11Part1.test;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class Program20 {
	
	public void  foo(Collection arg) {
		System.out.println("Bonjour  le  monde! ");
	}

}
 
