package com.java11Part1.test;

import java.io.FileReader;
import java.io.IOException;
import java.util.function.BiPredicate;



public class Program17 {

	public static void main(String[] args) {
			char[] Characters = new char[100];
			
			try(FileReader reader = new FileReader("C:\\Users\\003OQX744\\eclipse-workspace\\JavaSE\\src\\com\\java11Part1\\test\\Hello.txt");) {
				
			reader.read(Characters);
			//reader.readline();
				//Character.read();
				//Characters = reader.read();
			
			System.out.println(String.valueOf(Characters));
			
			Characters.clone();
				
			}catch(Exception e) {
				e.printStackTrace();
			}
	}

}
