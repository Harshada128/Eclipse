package com.java11Part1.test;

public class ApiImpl extends AbstractAPI implements APIInterface {

	public void process() {
		System.out.println("Process()called 2.");
	}
	
	public static void main(String[] args) {
		var impl = new ApiImpl();
		impl.process();
	}

}
