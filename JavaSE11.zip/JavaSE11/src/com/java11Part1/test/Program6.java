package com.java11Part1.test;

public class Program6 {

	public static void main(String[] args) {
		Person p = new Person("Joe");
		checkPerson(p);
		//Person q = checkPerson(p);
		System.out.println(p);
		//System.out.println("p is " + p);
		//System.out.println("q is " + q);
		
		p = null;
		checkPerson(p);
		//q = checkPerson(p);
		System.out.println(p);
		//System.out.println("q is " + q);
	}
	
	public static Person checkPerson(Person p) {
		//System.out.println(p);
		
		if(p == null) {
			p = new Person("Marry");
		}
		else {
			p = null;
		}
		
		//System.out.println(p);
		return p;
	}

}
