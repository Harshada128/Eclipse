package com.java11Part1.test;

public class Program12 {
	
	public enum Season{
		WINTER('w'),SPRING('s'),SUMMER('h'),FALL('f');
		char c;
		private Season(char c) {
			this.c=c;
		}
	}

	public static void main(String[] args) {
		Season[] sA = Season.values() ;
		System.out.println(Season.valueOf("SPRING").ordinal());//not print SPRING but print Location Of SPRING
		System.out.println(Season.SPRING);
	    //System.out.println(Season.values(1));
		System.out.println(Season.valueOf("SPRING"));
	   //System.out.println(Season.valueOf('s'));
		System.out.println(sA[0]);
		System.out.println(sA[1]);
		System.out.println(sA[2]);
		
	}

}
