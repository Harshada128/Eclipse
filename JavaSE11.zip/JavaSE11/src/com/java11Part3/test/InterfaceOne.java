package com.java11Part3.test;

public interface InterfaceOne {
	
	public void methodA();
	public void methodB();
	
	}
