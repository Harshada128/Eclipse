package com.java11Part3.test;

public class Resource implements AutoCloseable{
	
	public Resource() {
		System.out.print("A");
	}
	
	@Override
	public void close()
	{
		System.out.print("B");
	}
	
	public void printResource()
	{
		System.out.print("C");
	}

	public static void main(String args[]) {
	try(Resource r = new Resource()){
		r.printResource();
	}finally {
		System.out.print("D");
	}
	}
}
