package com.java11Part3.test;
//import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Locale;

public class LocalDate {

	@SuppressWarnings("deprecation")
	public static void main(String[] args) {

		Locale l = new Locale("en", "US");
		//LocalDate today = LocalDate.of(2018,12,17);
		//String mToday = today.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM));
		//String sToday = today.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT));
		//System.out.println(mToday);
		//System.out.println(sToday);

	}

	

}
