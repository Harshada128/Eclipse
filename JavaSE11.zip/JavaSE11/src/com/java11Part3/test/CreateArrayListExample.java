package com.java11Part3.test;

import java.util.ArrayList;
import java.util.List;

public class CreateArrayListExample {

	public static void main(String[] args) {
		List veg = new ArrayList<>();
		veg.add("Kale");
		veg.add(0 , "Letture");
		System.out.println(veg);
		List fish = new ArrayList<>();
		fish.add("Salmon");
		fish.add(0, "Seabass");
		System.out.println(fish);
	}

}
