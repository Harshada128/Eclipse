package com.java11Part3.test;

public class ResourceTest {

	public static void main(String[] args) {
		final MyResource res1 = new MyResource();
		MyResource res2 = new MyResource();
		try(res1 ; res2){
			// dcsdc
		}catch(Exception e) {}
	}
	
	static class MyResource implements AutoCloseable{
		public void close() throws Exception{}
	}

}
