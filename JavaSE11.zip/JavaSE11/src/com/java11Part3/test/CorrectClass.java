package com.java11Part3.test;

//public class CorrectClass extends AbstactClass {
//	public void methodC(String c) {
//		System.out.println(c);
//	}
//
//}
