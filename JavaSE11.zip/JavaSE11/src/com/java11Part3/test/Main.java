package com.java11Part3.test;

public class Main {
	
	static String prefix = "Modial:";
	private String name = "domanmodel";
	
	public static String getName() {
		return new Main().name;
		}

	public static void main(String[] args) {
		
		Main m = new Main();
		System.out.println(Main.prefix+Main.getName());
		System.out.println(new Main().prefix + new Main().getName());
		System.out.println(prefix + getName());
		}

}
