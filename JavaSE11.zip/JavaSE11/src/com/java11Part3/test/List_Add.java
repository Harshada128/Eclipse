package com.java11Part3.test;

import java.util.ArrayList;
import java.util.List;

public class List_Add {

	public static void main(String[] args) {
//		List even = List.of();
//		even.add(0, -1);
//		even.add(0, -2);
//		even.add(0, -3);
//		System.out.println(even);
		
		List<Integer> even = new ArrayList<>();
        even.add(0, -1);
        even.add(0, -2);
        even.add(0, -3);
        System.out.println(even);

	}

}
