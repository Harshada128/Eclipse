package com.java11Part3.test;

import java.util.stream.Stream;

public class IntStream {

	public static void main(String[] args) {

		var i = 1;
		var result = Stream.generate(() -> {return i;})  
				.limit(100);
		System.out.println(result);
	}

}
