package com.java11Part3.test;

public class Car {
	
	void wheels() {
	System.out.println(4);
 }
	public static void main(String[] args) {
	Car ob = new Car();
	ob.wheels();

}
}
