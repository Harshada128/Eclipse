package com.java11Part3.test;

//public interface InterfaceTwo extends AbstactClass {

//}
