package com.java11Part3.test;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Ffile {

	public static void main(String[] args) {
		
		String filename = "/u01/work" +args[0];
		
		Path file = Paths.get(filename);
		String canonicalpath = file.toAbsolutePath().toString();
		try {
			FileInputStream fis = new FileInputStream(canonicalpath);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
