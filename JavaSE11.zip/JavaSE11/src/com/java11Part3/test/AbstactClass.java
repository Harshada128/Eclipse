package com.java11Part3.test;

public abstract class AbstactClass implements InterfaceOne {
	public String origin = "Abstact Class";
	
	public void methodA() {
		System.out.print("A");
	}
	
	public abstract void methodC();

}
