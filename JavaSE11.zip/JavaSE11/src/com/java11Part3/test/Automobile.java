package com.java11Part3.test;

public abstract class Automobile {
	abstract void wheels();

}
